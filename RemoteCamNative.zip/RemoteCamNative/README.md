# RemoteCam Native (Camera2) — kualitas sensor maksimum

## Cara build
1. Buka folder ini di **Android Studio** (Koala atau lebih baru). Biarkan Gradle sync.
2. Colok Infinix Note 40 (USB debugging aktif) → Run ▶ atau Build > Build APK.
3. Izinkan Kamera + Mikrofon saat pertama dibuka.

## Mode foto (tombol "Foto:")
| Mode | Isi |
|---|---|
| **Terbaik** | JPEG ukuran terbesar "mode default" HP (umumnya hasil pixel-binning → bersih, low-light bagus). |
| **ULTRA Full-Sensor** | JPEG resolusi penuh sensor (mis. 108MP) lewat `SENSOR_PIXEL_MODE_MAXIMUM_RESOLUTION`. Hanya aktif bila HP mengekspos kapabilitas ULTRA_HIGH_RESOLUTION_SENSOR (baris info di atas layar menampilkan statusnya). |
| **RAW + JPEG** | DNG mentah sensor + JPEG terbaik. Edit di Lightroom / Snapseed. |

Semua foto: JPEG quality 100, noise reduction / edge / tonemap / shading / hot-pixel / aberrasi / distorsi = HIGH_QUALITY, OIS aktif, urutan kunci AF + AE sebelum jepret.
ULTRA: eksposur, fokus, dan white balance "dibekukan" dari frame preview terakhir agar hasil 108MP tidak salah ekspos.

## Video
4K30 / 2K30 / FHD60 / FHD30, bitrate tinggi, HEVC (hardware) bila ada, stabilisasi OIS + EIS bila didukung, audio AAC 256 kbps stereo 48 kHz tanpa pemrosesan (UNPROCESSED).

## Kontrol
Zoom hardware, EV, ISO + shutter manual, tap-to-focus. Hasil disimpan ke Pictures/RemoteCamPro dan Movies/RemoteCamPro.

## Batasan jujur
- Tidak memakai pipeline HDR/Night milik vendor (Transsion tidak membuka ke aplikasi pihak ketiga). Foto malam tetap bisa kalah dari kamera bawaan.
- Jika baris info menulis "ULTRA: tidak diekspos HP", mode ULTRA tidak bisa dipakai; gunakan Terbaik atau RAW.
- Kode belum dikompilasi/diuji di perangkat — kemungkinan ada penyesuaian kecil saat pertama build.
- Belum ada fitur remote (WebRTC). Tahap berikutnya: sambungkan ke `CameraEngine` (takePhoto, startRecording, setZoom, dst.).
