package com.remotecam.pro

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.graphics.ImageFormat
import android.graphics.Rect
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureFailure
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.CaptureResult
import android.hardware.camera2.DngCreator
import android.hardware.camera2.TotalCaptureResult
import android.hardware.camera2.params.ColorSpaceTransform
import android.hardware.camera2.params.MeteringRectangle
import android.hardware.camera2.params.OutputConfiguration
import android.hardware.camera2.params.RggbChannelVector
import android.hardware.camera2.params.SessionConfiguration
import android.hardware.camera2.params.StreamConfigurationMap
import android.media.AudioManager
import android.media.ExifInterface
import android.media.Image
import android.media.ImageReader
import android.media.MediaCodecList
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.util.Size
import android.view.Surface
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executor
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min

enum class PhotoMode(val label: String) {
    BEST("Terbaik"),            // JPEG ukuran maksimum "mode default" (biasanya hasil pixel-binning, bersih)
    ULTRA("ULTRA Full-Sensor"), // JPEG resolusi penuh sensor (mis. 108MP) bila HP mengekspos
    RAW("RAW + JPEG")           // DNG (file mentah sensor) + JPEG terbaik
}

data class VideoPreset(val label: String, val w: Int, val h: Int, val fps: Int, val bitrate: Int)

val VIDEO_PRESETS = listOf(
    VideoPreset("4K 30fps", 3840, 2160, 30, 60_000_000),
    VideoPreset("2K 30fps", 2560, 1440, 30, 36_000_000),
    VideoPreset("FHD 60fps", 1920, 1080, 60, 28_000_000),
    VideoPreset("FHD 30fps", 1920, 1080, 30, 18_000_000)
)

data class LensInfo(val id: String, val label: String)

interface EngineListener {
    fun onInfo(text: String)
    fun onToast(text: String)
    fun onPreviewSize(w: Int, h: Int)
    fun onRecording(active: Boolean)
    fun onReady()
}

@SuppressLint("NewApi", "MissingPermission")
class CameraEngine(private val ctx: Context, private val cb: EngineListener) {

    private enum class State { PREVIEW, WAITING_LOCK, WAITING_PRECAPTURE, WAITING_NON_PRECAPTURE, CAPTURING }

    private class Frozen(
        val exp: Long?, val iso: Int?, val focus: Float?,
        val gains: RggbChannelVector?, val xform: ColorSpaceTransform?
    )

    // ---------- infrastruktur ----------
    private val main = Handler(Looper.getMainLooper())
    private val thread = HandlerThread("CameraEngine").apply { start() }
    private val handler = Handler(thread.looper)
    private val executor = Executor { handler.post(it) }
    private val io = Executors.newSingleThreadExecutor()
    private val manager = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private val rawLock = Any()

    // ---------- state publik (dibaca UI) ----------
    @Volatile var deviceOrientation = 0
    var photoMode = PhotoMode.BEST; private set
    var videoPreset = VIDEO_PRESETS[2]
    var lenses: List<LensInfo> = emptyList(); private set
    @Volatile var isRecording = false; private set

    var zoom = 1f
    var evIndex = 0
    var manualExposure = false
    var iso = 100
    var exposureNs = 16_000_000L

    var zoomMax = 1f; private set
    var evMin = 0; private set
    var evMax = 0; private set
    var evStep = 0f; private set
    var isoMin = 100; private set
    var isoMax = 100; private set
    var expMin = 1_000_000L; private set
    var expMax = 1_000_000L; private set
    var canManual = false; private set

    // ---------- state internal ----------
    private var cameraId: String? = null
    private lateinit var chars: CameraCharacteristics
    private var map: StreamConfigurationMap? = null
    private var defaultJpeg: Size? = null
    private var ultraJpeg: Size? = null
    private var rawSize: Size? = null

    private var device: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var texture: SurfaceTexture? = null
    private var previewSurface: Surface? = null
    private var jpegReader: ImageReader? = null
    private var rawReader: ImageReader? = null
    private var ultraReader: ImageReader? = null
    private var previewBuilder: CaptureRequest.Builder? = null
    private var lastResult: TotalCaptureResult? = null
    private var state = State.PREVIEW

    private var pendingRaw: Image? = null
    private var pendingResult: TotalCaptureResult? = null

    private var frozen: Frozen? = null
    private var ultraRetried = false

    private var recorder: MediaRecorder? = null
    private var videoSurface: Surface? = null
    private var recUri: Uri? = null
    private var recPfd: ParcelFileDescriptor? = null

    // =====================================================================
    // Lensa & pembukaan kamera
    // =====================================================================
    fun loadLenses() {
        val back = mutableListOf<Pair<Double, LensInfo>>()
        val front = mutableListOf<LensInfo>()
        for (id in manager.cameraIdList) {
            val c = manager.getCameraCharacteristics(id)
            val caps = c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES) ?: continue
            if (!caps.contains(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_BACKWARD_COMPATIBLE)) continue
            val pa = c.get(CameraCharacteristics.SENSOR_INFO_PIXEL_ARRAY_SIZE)
            val mp = if (pa != null) pa.width.toLong() * pa.height / 1e6 else 0.0
            val focal = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.firstOrNull()
            val isFront = c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_FRONT
            val label = (if (isFront) "Depan" else "Belakang") + " #$id " +
                "%.0fMP".format(mp) + (if (focal != null) " %.1fmm".format(focal) else "")
            if (isFront) front += LensInfo(id, label) else back += mp to LensInfo(id, label)
        }
        lenses = back.sortedByDescending { it.first }.map { it.second } + front
    }

    fun open(id: String, surfaceTexture: SurfaceTexture) {
        texture = surfaceTexture
        handler.post {
            closeInternal()
            try {
                cameraId = id
                chars = manager.getCameraCharacteristics(id)
                computeInfo()
                manager.openCamera(id, object : CameraDevice.StateCallback() {
                    override fun onOpened(c: CameraDevice) { device = c; createPreviewSession() }
                    override fun onDisconnected(c: CameraDevice) { c.close(); device = null }
                    override fun onError(c: CameraDevice, error: Int) {
                        c.close(); device = null; toast("Kamera error ($error)")
                    }
                }, handler)
            } catch (e: Exception) {
                toast("Gagal membuka kamera: ${e.message}")
            }
        }
    }

    fun closeCamera() { handler.post { closeInternal() } }

    fun release() {
        handler.post { closeInternal() }
        thread.quitSafely()
        io.shutdown()
    }

    private fun closeInternal() {
        handler.removeCallbacksAndMessages(null)
        if (isRecording) finishRecording()
        try { session?.close() } catch (e: Exception) { }
        session = null
        closeReaders()
        ultraReader?.close(); ultraReader = null
        try { device?.close() } catch (e: Exception) { }
        device = null
        previewSurface?.release(); previewSurface = null
        previewBuilder = null
        lastResult = null
        state = State.PREVIEW
    }

    private fun closeReaders() {
        jpegReader?.close(); jpegReader = null
        rawReader?.close(); rawReader = null
        synchronized(rawLock) { pendingRaw?.close(); pendingRaw = null; pendingResult = null }
    }

    private fun hasCap(c: Int) = chars.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)?.contains(c) == true
    private fun IntArray?.has(v: Int) = this != null && this.contains(v)
    private fun Size.mp() = width.toLong() * height / 1e6
    private fun area(s: Size) = s.width.toLong() * s.height

    private fun computeInfo() {
        val c = chars
        map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
        defaultJpeg = map?.getOutputSizes(ImageFormat.JPEG)?.maxByOrNull { area(it) }
        rawSize = if (hasCap(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_RAW))
            map?.getOutputSizes(ImageFormat.RAW_SENSOR)?.maxByOrNull { area(it) } else null
        ultraJpeg = null
        if (Build.VERSION.SDK_INT >= 31 &&
            hasCap(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_ULTRA_HIGH_RESOLUTION_SENSOR)
        ) {
            ultraJpeg = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP_MAXIMUM_RESOLUTION)
                ?.getOutputSizes(ImageFormat.JPEG)?.maxByOrNull { area(it) }
        }

        zoomMax = min(10f, c.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE)?.upper ?: 1f)
        val ev = c.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE)
        evMin = ev?.lower ?: 0
        evMax = ev?.upper ?: 0
        evStep = c.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_STEP)?.toFloat() ?: 0f
        val isoR = c.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)
        isoMin = isoR?.lower ?: 100
        isoMax = min(isoR?.upper ?: 100, 3200)
        val expR = c.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)
        expMin = expR?.lower ?: 1_000_000L
        expMax = min(expR?.upper ?: 1_000_000L, 500_000_000L)
        canManual = hasCap(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR)

        zoom = 1f; evIndex = 0; manualExposure = false
        val text = buildString {
            append("Lensa ").append(cameraId)
            defaultJpeg?.let { append(" • Default ${it.width}×${it.height} (${"%.0f".format(it.mp())}MP)") }
            append(" • ULTRA: ")
            append(ultraJpeg?.let { "${it.width}×${it.height} (${"%.0f".format(it.mp())}MP)" } ?: "tidak diekspos HP")
            append(" • RAW: ").append(rawSize?.let { "${it.width}×${it.height}" } ?: "tidak ada")
        }
        main.post { cb.onInfo(text); cb.onReady() }
    }

    // =====================================================================
    // Sesi preview
    // =====================================================================
    private fun choosePreview(ratio: Float): Size {
        val sizes = map?.getOutputSizes(SurfaceTexture::class.java)?.toList().orEmpty()
        val ok = sizes.filter { it.width <= 1920 && it.height <= 1440 }
        return ok.filter { kotlin.math.abs(it.width.toFloat() / it.height - ratio) < 0.02f }.maxByOrNull { area(it) }
            ?: ok.maxByOrNull { area(it) } ?: Size(1280, 720)
    }

    private fun createPreviewSession(extraSurface: Surface? = null) {
        val dev = device ?: return
        val tex = texture ?: return
        try {
            try { session?.close() } catch (e: Exception) { }
            session = null
            closeReaders()
            state = State.PREVIEW

            val ratio = if (extraSurface != null) videoPreset.w.toFloat() / videoPreset.h
            else defaultJpeg?.let { it.width.toFloat() / it.height } ?: (4f / 3f)
            val pSize = choosePreview(ratio)
            tex.setDefaultBufferSize(pSize.width, pSize.height)
            main.post { cb.onPreviewSize(pSize.width, pSize.height) }

            previewSurface?.release()
            val pSurface = Surface(tex)
            previewSurface = pSurface
            val surfaces = mutableListOf(pSurface)

            if (extraSurface != null) {
                surfaces += extraSurface
            } else {
                defaultJpeg?.let { s ->
                    val r = ImageReader.newInstance(s.width, s.height, ImageFormat.JPEG, 2)
                    r.setOnImageAvailableListener(jpegListener, handler)
                    jpegReader = r; surfaces += r.surface
                }
                if (photoMode == PhotoMode.RAW) {
                    rawSize?.let { s ->
                        val r = ImageReader.newInstance(s.width, s.height, ImageFormat.RAW_SENSOR, 2)
                        r.setOnImageAvailableListener(rawListener, handler)
                        rawReader = r; surfaces += r.surface
                    }
                }
            }

            val cfg = SessionConfiguration(
                SessionConfiguration.SESSION_REGULAR,
                surfaces.map { OutputConfiguration(it) }, executor,
                object : CameraCaptureSession.StateCallback() {
                    override fun onConfigured(s: CameraCaptureSession) {
                        session = s
                        startRepeating(extraSurface != null)
                        if (extraSurface != null) {
                            try {
                                recorder?.start()
                                isRecording = true
                                main.post { cb.onRecording(true) }
                            } catch (e: Exception) {
                                toast("Gagal memulai rekaman: ${e.message}")
                                finishRecording()
                                createPreviewSession()
                            }
                        }
                    }
                    override fun onConfigureFailed(s: CameraCaptureSession) {
                        toast("Konfigurasi sesi kamera ditolak HP")
                        if (extraSurface != null) { finishRecording(); createPreviewSession() }
                    }
                })
            dev.createCaptureSession(cfg)
        } catch (e: Exception) {
            toast("Gagal membuat sesi: ${e.message}")
        }
    }

    private fun startRepeating(video: Boolean) {
        val dev = device ?: return
        val s = session ?: return
        val ps = previewSurface ?: return
        try {
            val b = dev.createCaptureRequest(if (video) CameraDevice.TEMPLATE_RECORD else CameraDevice.TEMPLATE_PREVIEW)
            b.addTarget(ps)
            if (video) videoSurface?.let { b.addTarget(it) }
            applyCommon(b, still = false, video = video)
            previewBuilder = b
            s.setRepeatingRequest(b.build(), previewCallback, handler)
        } catch (e: Exception) {
            toast("Preview gagal: ${e.message}")
        }
    }

    /** Parameter kontrol yang dipakai preview, video, dan foto. */
    private fun applyCommon(b: CaptureRequest.Builder, still: Boolean, video: Boolean, ultra: Boolean = false) {
        val c = chars
        val afModes = c.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES)
        b.set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO)
        when {
            video && afModes.has(CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_VIDEO) ->
                b.set(CaptureRequest.CONTROL_AF_MODE, CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_VIDEO)
            afModes.has(CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_PICTURE) ->
                b.set(CaptureRequest.CONTROL_AF_MODE, CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
            afModes.has(CameraMetadata.CONTROL_AF_MODE_AUTO) ->
                b.set(CaptureRequest.CONTROL_AF_MODE, CameraMetadata.CONTROL_AF_MODE_AUTO)
        }
        if (manualExposure && canManual) {
            b.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_OFF)
            b.set(CaptureRequest.SENSOR_EXPOSURE_TIME, exposureNs.coerceIn(expMin, expMax))
            b.set(CaptureRequest.SENSOR_SENSITIVITY, iso.coerceIn(isoMin, isoMax))
        } else {
            b.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_ON)
            b.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, evIndex)
        }
        b.set(CaptureRequest.CONTROL_AWB_MODE, CameraMetadata.CONTROL_AWB_MODE_AUTO)
        if (!ultra) b.set(CaptureRequest.CONTROL_ZOOM_RATIO, zoom.coerceIn(1f, zoomMax))

        if (c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION)
                .has(CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_ON)
        ) b.set(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE, CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_ON)

        if (video) {
            if (c.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES)
                    .has(CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_ON)
            ) b.set(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE, CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_ON)
            val fps = videoPreset.fps
            c.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)
                ?.filter { it.upper == fps }?.maxByOrNull { it.lower }
                ?.let { b.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, it) }
        }
        if (still) applyQuality(b)
    }

    /** Semua mode pemrosesan gambar diset ke HIGH_QUALITY bila HP mendukung. */
    private fun applyQuality(b: CaptureRequest.Builder) {
        val c = chars
        b.set(CaptureRequest.JPEG_QUALITY, 100.toByte())
        if (c.get(CameraCharacteristics.NOISE_REDUCTION_AVAILABLE_NOISE_REDUCTION_MODES)
                .has(CameraMetadata.NOISE_REDUCTION_MODE_HIGH_QUALITY))
            b.set(CaptureRequest.NOISE_REDUCTION_MODE, CameraMetadata.NOISE_REDUCTION_MODE_HIGH_QUALITY)
        if (c.get(CameraCharacteristics.EDGE_AVAILABLE_EDGE_MODES).has(CameraMetadata.EDGE_MODE_HIGH_QUALITY))
            b.set(CaptureRequest.EDGE_MODE, CameraMetadata.EDGE_MODE_HIGH_QUALITY)
        if (c.get(CameraCharacteristics.COLOR_CORRECTION_AVAILABLE_ABERRATION_MODES)
                .has(CameraMetadata.COLOR_CORRECTION_ABERRATION_MODE_HIGH_QUALITY))
            b.set(CaptureRequest.COLOR_CORRECTION_ABERRATION_MODE, CameraMetadata.COLOR_CORRECTION_ABERRATION_MODE_HIGH_QUALITY)
        if (c.get(CameraCharacteristics.HOT_PIXEL_AVAILABLE_HOT_PIXEL_MODES).has(CameraMetadata.HOT_PIXEL_MODE_HIGH_QUALITY))
            b.set(CaptureRequest.HOT_PIXEL_MODE, CameraMetadata.HOT_PIXEL_MODE_HIGH_QUALITY)
        if (c.get(CameraCharacteristics.SHADING_AVAILABLE_MODES).has(CameraMetadata.SHADING_MODE_HIGH_QUALITY))
            b.set(CaptureRequest.SHADING_MODE, CameraMetadata.SHADING_MODE_HIGH_QUALITY)
        if (c.get(CameraCharacteristics.TONEMAP_AVAILABLE_TONE_MAP_MODES).has(CameraMetadata.TONEMAP_MODE_HIGH_QUALITY))
            b.set(CaptureRequest.TONEMAP_MODE, CameraMetadata.TONEMAP_MODE_HIGH_QUALITY)
        if (c.get(CameraCharacteristics.DISTORTION_CORRECTION_AVAILABLE_MODES)
                .has(CameraMetadata.DISTORTION_CORRECTION_MODE_HIGH_QUALITY))
            b.set(CaptureRequest.DISTORTION_CORRECTION_MODE, CameraMetadata.DISTORTION_CORRECTION_MODE_HIGH_QUALITY)
    }

    // =====================================================================
    // Kontrol live
    // =====================================================================
    fun changePhotoMode(m: PhotoMode) {
        handler.post {
            val rebuild = (photoMode == PhotoMode.RAW) != (m == PhotoMode.RAW)
            photoMode = m
            if (rebuild && device != null && !isRecording && state == State.PREVIEW) createPreviewSession()
        }
    }

    fun updateRepeating() {
        handler.post {
            val b = previewBuilder ?: return@post
            val s = session ?: return@post
            if (state != State.PREVIEW) return@post
            try {
                applyCommon(b, still = false, video = isRecording)
                s.setRepeatingRequest(b.build(), previewCallback, handler)
            } catch (e: Exception) { }
        }
    }

    /** nx, ny = posisi sentuh 0..1 pada preview (tampilan tegak). */
    fun focusAt(nx: Float, ny: Float) {
        handler.post {
            val b = previewBuilder ?: return@post
            val s = session ?: return@post
            val arr = chars.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE) ?: return@post
            val (sx, sy) = when (chars.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90) {
                90 -> ny to (1f - nx)
                270 -> (1f - ny) to nx
                180 -> (1f - nx) to (1f - ny)
                else -> nx to ny
            }
            val half = (min(arr.width(), arr.height()) * 0.06f).toInt()
            val cx = arr.left + (sx * arr.width()).toInt()
            val cy = arr.top + (sy * arr.height()).toInt()
            val rect = Rect(
                max(arr.left, cx - half), max(arr.top, cy - half),
                min(arr.right - 1, cx + half), min(arr.bottom - 1, cy + half)
            )
            val region = arrayOf(MeteringRectangle(rect, MeteringRectangle.METERING_WEIGHT_MAX - 1))
            try {
                if ((chars.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AF) ?: 0) > 0)
                    b.set(CaptureRequest.CONTROL_AF_REGIONS, region)
                if ((chars.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AE) ?: 0) > 0)
                    b.set(CaptureRequest.CONTROL_AE_REGIONS, region)
                b.set(CaptureRequest.CONTROL_AF_TRIGGER, CameraMetadata.CONTROL_AF_TRIGGER_START)
                s.capture(b.build(), previewCallback, handler)
                b.set(CaptureRequest.CONTROL_AF_TRIGGER, CameraMetadata.CONTROL_AF_TRIGGER_IDLE)
                s.setRepeatingRequest(b.build(), previewCallback, handler)
            } catch (e: Exception) { }
        }
    }

    // =====================================================================
    // Foto: urutan lock AF -> precapture AE -> capture
    // =====================================================================
    private val previewCallback = object : CameraCaptureSession.CaptureCallback() {
        override fun onCaptureProgressed(s: CameraCaptureSession, r: CaptureRequest, p: CaptureResult) = process(p)
        override fun onCaptureCompleted(s: CameraCaptureSession, r: CaptureRequest, res: TotalCaptureResult) {
            lastResult = res
            process(res)
        }
    }

    private val lockTimeout = Runnable {
        if (state == State.WAITING_LOCK || state == State.WAITING_PRECAPTURE || state == State.WAITING_NON_PRECAPTURE) fireStill()
    }

    private fun process(res: CaptureResult) {
        when (state) {
            State.WAITING_LOCK -> {
                val af = res.get(CaptureResult.CONTROL_AF_STATE)
                if (af == null || af == CaptureResult.CONTROL_AF_STATE_FOCUSED_LOCKED ||
                    af == CaptureResult.CONTROL_AF_STATE_NOT_FOCUSED_LOCKED
                ) {
                    val ae = res.get(CaptureResult.CONTROL_AE_STATE)
                    if (ae == null || ae == CaptureResult.CONTROL_AE_STATE_CONVERGED || manualExposure) fireStill()
                    else runPrecapture()
                }
            }
            State.WAITING_PRECAPTURE -> {
                val ae = res.get(CaptureResult.CONTROL_AE_STATE)
                if (ae == null || ae == CaptureResult.CONTROL_AE_STATE_PRECAPTURE ||
                    ae == CaptureResult.CONTROL_AE_STATE_FLASH_REQUIRED || ae == CaptureResult.CONTROL_AE_STATE_CONVERGED
                ) state = State.WAITING_NON_PRECAPTURE
            }
            State.WAITING_NON_PRECAPTURE -> {
                val ae = res.get(CaptureResult.CONTROL_AE_STATE)
                if (ae == null || ae != CaptureResult.CONTROL_AE_STATE_PRECAPTURE) fireStill()
            }
            else -> {}
        }
    }

    fun takePhoto() {
        handler.post {
            if (session == null || isRecording || state != State.PREVIEW) return@post
            if (photoMode == PhotoMode.ULTRA && ultraJpeg == null)
                toast("Full-sensor tidak diekspos HP untuk lensa ini → memakai mode Terbaik")
            val afModes = chars.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES)
            val hasAf = afModes.has(CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_PICTURE) || afModes.has(CameraMetadata.CONTROL_AF_MODE_AUTO)
            if (hasAf) lockFocus() else { state = State.WAITING_NON_PRECAPTURE; fireStill() }
        }
    }

    private fun lockFocus() {
        val b = previewBuilder ?: return
        val s = session ?: return
        try {
            state = State.WAITING_LOCK
            b.set(CaptureRequest.CONTROL_AF_TRIGGER, CameraMetadata.CONTROL_AF_TRIGGER_START)
            s.capture(b.build(), previewCallback, handler)
            b.set(CaptureRequest.CONTROL_AF_TRIGGER, CameraMetadata.CONTROL_AF_TRIGGER_IDLE)
            handler.postDelayed(lockTimeout, 3000)
        } catch (e: Exception) { state = State.PREVIEW }
    }

    private fun runPrecapture() {
        val b = previewBuilder ?: return
        val s = session ?: return
        try {
            state = State.WAITING_PRECAPTURE
            b.set(CaptureRequest.CONTROL_AE_PRECAPTURE_TRIGGER, CameraMetadata.CONTROL_AE_PRECAPTURE_TRIGGER_START)
            s.capture(b.build(), previewCallback, handler)
            b.set(CaptureRequest.CONTROL_AE_PRECAPTURE_TRIGGER, CameraMetadata.CONTROL_AE_PRECAPTURE_TRIGGER_IDLE)
        } catch (e: Exception) { state = State.PREVIEW }
    }

    private fun fireStill() {
        handler.removeCallbacks(lockTimeout)
        if (state == State.CAPTURING) return
        state = State.CAPTURING
        if (photoMode == PhotoMode.ULTRA && ultraJpeg != null) { captureUltra(); return }
        val dev = device
        val s = session
        val jr = jpegReader
        if (dev == null || s == null || jr == null) { state = State.PREVIEW; return }
        try {
            val b = dev.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE)
            b.addTarget(jr.surface)
            if (photoMode == PhotoMode.RAW) rawReader?.let { b.addTarget(it.surface) }
            applyCommon(b, still = true, video = false)
            b.set(CaptureRequest.JPEG_ORIENTATION, jpegOrientation())
            s.capture(b.build(), stillCallback, handler)
        } catch (e: Exception) {
            toast("Capture gagal: ${e.message}"); state = State.PREVIEW
        }
    }

    private val stillCallback = object : CameraCaptureSession.CaptureCallback() {
        override fun onCaptureCompleted(s: CameraCaptureSession, r: CaptureRequest, result: TotalCaptureResult) {
            if (photoMode == PhotoMode.RAW) {
                synchronized(rawLock) { pendingResult = result }
                tryFinishRaw()
            }
            unlockFocus()
        }
        override fun onCaptureFailed(s: CameraCaptureSession, r: CaptureRequest, f: CaptureFailure) {
            toast("Capture gagal"); unlockFocus()
        }
    }

    private fun unlockFocus() {
        val b = previewBuilder
        val s = session
        if (b == null || s == null) { state = State.PREVIEW; return }
        try {
            b.set(CaptureRequest.CONTROL_AF_TRIGGER, CameraMetadata.CONTROL_AF_TRIGGER_CANCEL)
            s.capture(b.build(), previewCallback, handler)
            b.set(CaptureRequest.CONTROL_AF_TRIGGER, CameraMetadata.CONTROL_AF_TRIGGER_IDLE)
            s.setRepeatingRequest(b.build(), previewCallback, handler)
        } catch (e: Exception) { }
        state = State.PREVIEW
    }

    // ---------- penyimpanan JPEG / DNG ----------
    private val jpegListener = ImageReader.OnImageAvailableListener { r ->
        val img = r.acquireNextImage() ?: return@OnImageAvailableListener
        val bytes = try {
            val buf = img.planes[0].buffer
            ByteArray(buf.remaining()).also { buf.get(it) }
        } finally { img.close() }
        io.execute { saveJpeg(bytes, if (photoMode == PhotoMode.RAW) "_JPG" else "") }
    }

    private val rawListener = ImageReader.OnImageAvailableListener { r ->
        val img = r.acquireNextImage() ?: return@OnImageAvailableListener
        synchronized(rawLock) { pendingRaw?.close(); pendingRaw = img }
        tryFinishRaw()
    }

    private fun tryFinishRaw() {
        val pair = synchronized(rawLock) {
            val i = pendingRaw
            val r = pendingResult
            if (i != null && r != null) { pendingRaw = null; pendingResult = null; i to r } else null
        } ?: return
        val (img, res) = pair
        val c = chars
        val orient = exifOrientation()
        io.execute {
            try {
                val uri = saveMedia(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "RAW_${stamp()}.dng",
                    "image/x-adobe-dng", "Pictures/RemoteCamPro") { os ->
                    val dng = DngCreator(c, res)
                    dng.setOrientation(orient)
                    dng.writeImage(os, img)
                    dng.close()
                }
                toast(if (uri != null) "DNG RAW tersimpan" else "Gagal menyimpan DNG")
            } finally { img.close() }
        }
    }

    private fun saveJpeg(bytes: ByteArray, tag: String) {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
        val uri = saveMedia(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "IMG_${stamp()}$tag.jpg",
            "image/jpeg", "Pictures/RemoteCamPro") { it.write(bytes) }
        toast(if (uri != null) "Foto ${o.outWidth}×${o.outHeight} • ${"%.1f".format(bytes.size / 1048576f)} MB tersimpan"
        else "Gagal menyimpan foto")
    }

    private fun saveMedia(collection: Uri, name: String, mime: String, rel: String, write: (OutputStream) -> Unit): Uri? {
        val cr = ctx.contentResolver
        val v = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, rel)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val uri = cr.insert(collection, v) ?: return null
        return try {
            cr.openOutputStream(uri)?.use(write)
            v.clear(); v.put(MediaStore.MediaColumns.IS_PENDING, 0)
            cr.update(uri, v, null, null)
            uri
        } catch (e: Exception) {
            cr.delete(uri, null, null); null
        }
    }

    // =====================================================================
    // ULTRA: resolusi penuh sensor (mis. 108MP) — 3A dibekukan dari preview
    // =====================================================================
    private fun captureUltra() {
        val dev = device
        val size = ultraJpeg
        if (dev == null || size == null) { state = State.PREVIEW; return }
        val last = lastResult
        frozen = Frozen(
            last?.get(CaptureResult.SENSOR_EXPOSURE_TIME), last?.get(CaptureResult.SENSOR_SENSITIVITY),
            last?.get(CaptureResult.LENS_FOCUS_DISTANCE),
            last?.get(CaptureResult.COLOR_CORRECTION_GAINS), last?.get(CaptureResult.COLOR_CORRECTION_TRANSFORM)
        )
        ultraRetried = false
        toast("Memproses full-sensor ${size.width}×${size.height}…")
        try {
            try { session?.close() } catch (e: Exception) { }
            session = null
            closeReaders()
            val reader = ImageReader.newInstance(size.width, size.height, ImageFormat.JPEG, 1)
            ultraReader = reader
            reader.setOnImageAvailableListener({ r ->
                val img = r.acquireNextImage() ?: return@setOnImageAvailableListener
                val bytes = try {
                    val buf = img.planes[0].buffer
                    ByteArray(buf.remaining()).also { buf.get(it) }
                } finally { img.close() }
                io.execute { saveJpeg(bytes, "_ULTRA") }
                handler.post { restoreAfterUltra() }
            }, handler)

            val oc = OutputConfiguration(reader.surface)
            if (Build.VERSION.SDK_INT >= 33)
                oc.addSensorPixelModeUsed(CameraMetadata.SENSOR_PIXEL_MODE_MAXIMUM_RESOLUTION)

            dev.createCaptureSession(SessionConfiguration(
                SessionConfiguration.SESSION_REGULAR, listOf(oc), executor,
                object : CameraCaptureSession.StateCallback() {
                    override fun onConfigured(s: CameraCaptureSession) { session = s; shootUltra(s, reader, false) }
                    override fun onConfigureFailed(s: CameraCaptureSession) {
                        toast("HP menolak mode full-sensor. Gunakan mode Terbaik.")
                        restoreAfterUltra()
                    }
                }))
        } catch (e: Exception) {
            toast("Full-sensor gagal: ${e.message}")
            restoreAfterUltra()
        }
    }

    private fun shootUltra(s: CameraCaptureSession, reader: ImageReader, bare: Boolean) {
        val dev = device ?: return
        try {
            val b = dev.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE)
            b.addTarget(reader.surface)
            b.set(CaptureRequest.SENSOR_PIXEL_MODE, CameraMetadata.SENSOR_PIXEL_MODE_MAXIMUM_RESOLUTION)
            b.set(CaptureRequest.JPEG_ORIENTATION, jpegOrientation())
            b.set(CaptureRequest.JPEG_QUALITY, 100.toByte())
            if (!bare) {
                applyCommon(b, still = true, video = false, ultra = true)
                val f = frozen
                if (f != null && canManual && f.exp != null && f.iso != null) {
                    b.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_OFF)
                    b.set(CaptureRequest.SENSOR_EXPOSURE_TIME, f.exp)
                    b.set(CaptureRequest.SENSOR_SENSITIVITY, f.iso)
                }
                val minFocus = chars.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f
                if (f != null && f.focus != null && minFocus > 0f) {
                    b.set(CaptureRequest.CONTROL_AF_MODE, CameraMetadata.CONTROL_AF_MODE_OFF)
                    b.set(CaptureRequest.LENS_FOCUS_DISTANCE, f.focus)
                }
                if (f != null && f.gains != null && f.xform != null &&
                    hasCap(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_POST_PROCESSING)
                ) {
                    b.set(CaptureRequest.CONTROL_AWB_MODE, CameraMetadata.CONTROL_AWB_MODE_OFF)
                    b.set(CaptureRequest.COLOR_CORRECTION_MODE, CameraMetadata.COLOR_CORRECTION_MODE_TRANSFORM_MATRIX)
                    b.set(CaptureRequest.COLOR_CORRECTION_GAINS, f.gains)
                    b.set(CaptureRequest.COLOR_CORRECTION_TRANSFORM, f.xform)
                }
            }
            s.capture(b.build(), object : CameraCaptureSession.CaptureCallback() {
                override fun onCaptureFailed(sess: CameraCaptureSession, r: CaptureRequest, f: CaptureFailure) {
                    if (!ultraRetried) { ultraRetried = true; shootUltra(sess, reader, true) }
                    else { toast("Capture full-sensor gagal"); restoreAfterUltra() }
                }
            }, handler)
        } catch (e: Exception) {
            toast("Full-sensor gagal: ${e.message}"); restoreAfterUltra()
        }
    }

    private fun restoreAfterUltra() {
        ultraReader?.close(); ultraReader = null
        try { session?.close() } catch (e: Exception) { }
        session = null
        state = State.PREVIEW
        createPreviewSession()
    }

    // =====================================================================
    // Video
    // =====================================================================
    fun startRecording() {
        handler.post {
            if (isRecording || state != State.PREVIEW || device == null) return@post
            try {
                val p = videoPreset
                val sizes = map?.getOutputSizes(MediaRecorder::class.java)?.toList().orEmpty()
                val size = sizes.firstOrNull { it.width == p.w && it.height == p.h }
                    ?: sizes.filter { it.width * 9 == it.height * 16 && it.width <= p.w }.maxByOrNull { it.width }
                if (size == null) { toast("Ukuran ${p.label} tidak tersedia di lensa ini"); return@post }
                val rec = buildRecorder(size, p)
                recorder = rec
                videoSurface = rec.surface
                createPreviewSession(rec.surface)
            } catch (e: Exception) {
                toast("Gagal menyiapkan rekaman: ${e.message}")
                finishRecording()
            }
        }
    }

    private fun hasHardwareHevc() = MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.any { info ->
        info.isEncoder && info.isHardwareAccelerated && info.supportedTypes.any { it.equals("video/hevc", true) }
    }

    @Suppress("DEPRECATION")
    private fun buildRecorder(size: Size, p: VideoPreset): MediaRecorder {
        val rec = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else MediaRecorder()
        val audioOk = ctx.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (audioOk) {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val unprocessed = am.getProperty(AudioManager.PROPERTY_SUPPORT_AUDIO_SOURCE_UNPROCESSED) == "true"
            rec.setAudioSource(if (unprocessed) MediaRecorder.AudioSource.UNPROCESSED else MediaRecorder.AudioSource.CAMCORDER)
        }
        rec.setVideoSource(MediaRecorder.VideoSource.SURFACE)
        rec.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)

        val v = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "VID_${stamp()}.mp4")
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/RemoteCamPro")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val uri = ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v)
            ?: throw IllegalStateException("MediaStore menolak membuat file video")
        recUri = uri
        val pfd = ctx.contentResolver.openFileDescriptor(uri, "w") ?: throw IllegalStateException("Tidak bisa membuka file video")
        recPfd = pfd
        rec.setOutputFile(pfd.fileDescriptor)

        rec.setVideoEncodingBitRate(p.bitrate)
        rec.setVideoFrameRate(p.fps)
        rec.setVideoSize(size.width, size.height)
        rec.setVideoEncoder(if (hasHardwareHevc()) MediaRecorder.VideoEncoder.HEVC else MediaRecorder.VideoEncoder.H264)
        if (audioOk) {
            rec.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            rec.setAudioEncodingBitRate(256_000)
            rec.setAudioSamplingRate(48_000)
            rec.setAudioChannels(2)
        }
        rec.setOrientationHint(jpegOrientation())
        rec.prepare()
        return rec
    }

    fun stopRecording() {
        handler.post {
            if (!isRecording) return@post
            finishRecording()
            createPreviewSession()
        }
    }

    private fun finishRecording() {
        val wasRecording = isRecording
        isRecording = false
        try { session?.stopRepeating(); session?.abortCaptures() } catch (e: Exception) { }
        val rec = recorder
        recorder = null
        var ok = wasRecording
        try { rec?.stop() } catch (e: RuntimeException) { ok = false }
        try { rec?.reset(); rec?.release() } catch (e: Exception) { }
        try { recPfd?.close() } catch (e: Exception) { }
        recPfd = null
        val uri = recUri
        recUri = null
        if (uri != null) {
            if (ok) {
                val v = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                ctx.contentResolver.update(uri, v, null, null)
                toast("Video tersimpan di Movies/RemoteCamPro")
            } else ctx.contentResolver.delete(uri, null, null)
        }
        videoSurface = null
        main.post { cb.onRecording(false) }
    }

    // =====================================================================
    // Util
    // =====================================================================
    private fun jpegOrientation(): Int {
        val so = chars.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
        var d = (deviceOrientation + 45) / 90 * 90
        if (chars.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_FRONT) d = -d
        return (so + d + 360) % 360
    }

    private fun exifOrientation() = when (jpegOrientation()) {
        90 -> ExifInterface.ORIENTATION_ROTATE_90
        180 -> ExifInterface.ORIENTATION_ROTATE_180
        270 -> ExifInterface.ORIENTATION_ROTATE_270
        else -> ExifInterface.ORIENTATION_NORMAL
    }

    private fun stamp() = SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date())
    private fun toast(s: String) { main.post { cb.onToast(s) } }
}
