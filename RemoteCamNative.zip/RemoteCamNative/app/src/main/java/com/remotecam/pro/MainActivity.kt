package com.remotecam.pro

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.SurfaceTexture
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.OrientationEventListener
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.pow

class MainActivity : AppCompatActivity(), EngineListener {

    private lateinit var engine: CameraEngine
    private lateinit var frame: FrameLayout
    private lateinit var tv: TextureView
    private lateinit var info: TextView
    private lateinit var zoomBar: SeekBar
    private lateinit var evBar: SeekBar
    private lateinit var isoBar: SeekBar
    private lateinit var expBar: SeekBar
    private lateinit var zoomLabel: TextView
    private lateinit var evLabel: TextView
    private lateinit var isoLabel: TextView
    private lateinit var expLabel: TextView
    private lateinit var manualBox: CheckBox
    private lateinit var manualRow: LinearLayout
    private lateinit var btnLens: Button
    private lateinit var btnMode: Button
    private lateinit var btnVideo: Button
    private lateinit var btnShutter: Button
    private lateinit var btnRec: Button
    private lateinit var orientation: OrientationEventListener

    private var lensIndex = 0
    private var videoIndex = 2
    private var previewAspect = 4f / 3f

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { tryOpen() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        engine = CameraEngine(this, this)
        setContentView(buildUi())
        orientation = object : OrientationEventListener(this) {
            override fun onOrientationChanged(o: Int) {
                if (o != ORIENTATION_UNKNOWN) engine.deviceOrientation = o
            }
        }
        if (!hasCameraPermission()) {
            permLauncher.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
        }
    }

    override fun onResume() {
        super.onResume()
        orientation.enable()
        tryOpen()
    }

    override fun onPause() {
        orientation.disable()
        engine.closeCamera()
        super.onPause()
    }

    override fun onDestroy() {
        engine.release()
        super.onDestroy()
    }

    private fun hasCameraPermission() =
        checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    private fun tryOpen() {
        if (!hasCameraPermission() || !tv.isAvailable) return
        if (engine.lenses.isEmpty()) engine.loadLenses()
        val lens = engine.lenses.getOrNull(lensIndex) ?: return
        btnLens.text = lens.label
        engine.open(lens.id, tv.surfaceTexture ?: return)
    }

    // ---------------------------------------------------------------- EngineListener
    override fun onInfo(text: String) { info.text = text }
    override fun onToast(text: String) { Toast.makeText(this, text, Toast.LENGTH_SHORT).show() }

    override fun onPreviewSize(w: Int, h: Int) {
        previewAspect = w.toFloat() / h
        frame.post { layoutPreview() }
    }

    override fun onRecording(active: Boolean) {
        btnRec.text = if (active) "■ Stop" else "● Rekam"
        btnShutter.isEnabled = !active
        btnLens.isEnabled = !active
        btnMode.isEnabled = !active
        btnVideo.isEnabled = !active
    }

    override fun onReady() {
        zoomBar.progress = 0; zoomLabel.text = "Zoom 1.0x"
        evBar.max = engine.evMax - engine.evMin
        evBar.progress = -engine.evMin
        evLabel.text = "EV 0"
        manualBox.isEnabled = engine.canManual
        manualBox.isChecked = false
        manualRow.visibility = View.GONE
    }

    // ---------------------------------------------------------------- UI
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun layoutPreview() {
        val fw = frame.width
        val fh = frame.height
        if (fw == 0 || fh == 0) return
        var vw = fw
        var vh = (fw * previewAspect).toInt()   // preview tegak: tinggi = lebar × (lebarBuffer/tinggiBuffer)
        if (vh > fh) { vh = fh; vw = (fh / previewAspect).toInt() }
        tv.layoutParams = FrameLayout.LayoutParams(vw, vh, Gravity.CENTER)
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = text; setTextColor(Color.LTGRAY); textSize = 11f
        layoutParams = LinearLayout.LayoutParams(dp(78), ViewGroup.LayoutParams.WRAP_CONTENT)
    }

    private fun btn(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text; isAllCaps = false; textSize = 11f
        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        setOnClickListener { onClick() }
    }

    private fun onProgress(sb: SeekBar, f: (Int) -> Unit) {
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) { if (fromUser) f(p) }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
    }

    private fun seekRow(lbl: TextView, bar: SeekBar) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        addView(lbl)
        bar.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        addView(bar)
    }

    private fun logMap(p: Int, lo: Double, hi: Double) = lo * (hi / lo).pow(p / 100.0)

    private fun shutterText(ns: Long) =
        if (ns >= 1_000_000_000L) "%.1fs".format(ns / 1e9) else "1/${(1e9 / ns).toInt()}s"

    private fun applyManualFromBars() {
        engine.iso = logMap(isoBar.progress, engine.isoMin.toDouble(), engine.isoMax.toDouble()).toInt()
        engine.exposureNs = logMap(expBar.progress, engine.expMin.toDouble(), engine.expMax.toDouble()).toLong()
        isoLabel.text = "ISO ${engine.iso}"
        expLabel.text = shutterText(engine.exposureNs)
        engine.updateRepeating()
    }

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            setPadding(dp(8), dp(24), dp(8), dp(8))
        }

        info = TextView(this).apply { setTextColor(Color.parseColor("#9CA3AF")); textSize = 10f }
        root.addView(info)

        frame = FrameLayout(this)
        root.addView(frame, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        tv = TextureView(this)
        frame.addView(tv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        frame.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> layoutPreview() }
        tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) { tryOpen() }
            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {}
            override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean { engine.closeCamera(); return true }
            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
        }
        tv.setOnTouchListener { v, e ->
            if (e.action == MotionEvent.ACTION_UP && v.width > 0 && v.height > 0)
                engine.focusAt(e.x / v.width, e.y / v.height)
            true
        }

        // Zoom
        zoomLabel = label("Zoom 1.0x")
        zoomBar = SeekBar(this).apply { max = 100 }
        onProgress(zoomBar) { p ->
            engine.zoom = 1f + p / 100f * (engine.zoomMax - 1f)
            zoomLabel.text = "Zoom %.1fx".format(engine.zoom)
            engine.updateRepeating()
        }
        root.addView(seekRow(zoomLabel, zoomBar))

        // Kompensasi eksposur
        evLabel = label("EV 0")
        evBar = SeekBar(this)
        onProgress(evBar) { p ->
            engine.evIndex = engine.evMin + p
            evLabel.text = "EV %+.1f".format(engine.evIndex * engine.evStep)
            engine.updateRepeating()
        }
        root.addView(seekRow(evLabel, evBar))

        // Manual ISO + shutter
        manualBox = CheckBox(this).apply {
            text = "Manual ISO / Shutter"; setTextColor(Color.LTGRAY); textSize = 11f
        }
        root.addView(manualBox)
        isoLabel = label("ISO"); isoBar = SeekBar(this).apply { max = 100; progress = 20 }
        expLabel = label("Shutter"); expBar = SeekBar(this).apply { max = 100; progress = 55 }
        onProgress(isoBar) { applyManualFromBars() }
        onProgress(expBar) { applyManualFromBars() }
        manualRow = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            addView(seekRow(isoLabel, isoBar))
            addView(seekRow(expLabel, expBar))
        }
        root.addView(manualRow)
        manualBox.setOnCheckedChangeListener { _, on ->
            engine.manualExposure = on
            manualRow.visibility = if (on) View.VISIBLE else View.GONE
            if (on) applyManualFromBars() else engine.updateRepeating()
        }

        // Baris tombol 1: lensa, mode foto, preset video
        btnLens = btn("Lensa") {
            if (engine.lenses.isNotEmpty()) {
                lensIndex = (lensIndex + 1) % engine.lenses.size
                tryOpen()
            }
        }
        btnMode = btn("Foto: ${PhotoMode.BEST.label}") {
            val modes = PhotoMode.values()
            val next = modes[(engine.photoMode.ordinal + 1) % modes.size]
            engine.changePhotoMode(next)
            btnMode.text = "Foto: ${next.label}"
        }
        btnVideo = btn("Video: ${VIDEO_PRESETS[videoIndex].label}") {
            videoIndex = (videoIndex + 1) % VIDEO_PRESETS.size
            engine.videoPreset = VIDEO_PRESETS[videoIndex]
            btnVideo.text = "Video: ${VIDEO_PRESETS[videoIndex].label}"
        }
        engine.videoPreset = VIDEO_PRESETS[videoIndex]
        root.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(btnLens); addView(btnMode); addView(btnVideo)
        })

        // Baris tombol 2: shutter & rekam
        btnShutter = btn("◉ FOTO") { engine.takePhoto() }.apply { textSize = 16f }
        btnRec = btn("● Rekam") {
            if (engine.isRecording) engine.stopRecording() else engine.startRecording()
        }.apply { textSize = 14f }
        root.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(btnShutter); addView(btnRec)
        })
        return root
    }
}
